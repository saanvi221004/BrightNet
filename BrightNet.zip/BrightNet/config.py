import os

class Config:
    SECRET_KEY = 'saanvi@1234'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://saanvi:1234@localhost/brightnet'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
